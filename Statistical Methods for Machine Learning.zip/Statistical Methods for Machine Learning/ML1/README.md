ML1
===

The first assignment in Statistical Methods for Machine Learning

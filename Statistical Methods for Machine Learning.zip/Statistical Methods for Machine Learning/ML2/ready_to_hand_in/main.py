from __future__ import division
import numpy
from matplotlib import pylab as plt
import LDA
import sunspots

"""
Part 1
""" 
#LDA
#Called when importing the file

print "*" * 45

"""
Part 2
"""
print "Regression"
print "-"*45
#calls file sunspots.py
#outputs 3 plots and RMS for ML
sunspots.run()
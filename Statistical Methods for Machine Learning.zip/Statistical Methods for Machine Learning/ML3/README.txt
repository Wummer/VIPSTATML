*************************************
Required modules:
-----------------

numpy
Scikit-Learn (sklearn)
pylab
random
operator
collections
-------------------------------------

Running the program:
--------------------

Initialize the main.py from your
terminal or preferred IDE.

Be mindful that running the NN is
time consuming since it requires
you to train the network on the data
before predicting. 
It also set to run with 20 hidden
neurons, but this can be changed in
nn.py . 

Be mindful that the current setting
of epoch is 1000 so it runs faster.

To test the other epocch values you
can change the epoch value in main.py
line 31. 

*************************************

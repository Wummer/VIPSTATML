-----------------------------------------------------------
REQUIRED NON-STANDARD LIBRARIES

Numpy
Sklearn
Pylab
LaTeX*

*LaTeX is used for nice formatting of pylab.
 It can be disabled by uncommenting line 16 & 17 in main.py

-----------------------------------------------------------
HOW TO RUN:

Run main.py from the terminal or your favourite IDE.
The script requires /data as a subfolder.

-----------------------------------------------------------
RUNTIME:

On my laptop:
[Finished in 291.8s]
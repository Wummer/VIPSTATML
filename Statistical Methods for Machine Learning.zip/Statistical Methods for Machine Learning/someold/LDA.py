from __future__ import division
import numpy as np
from collections import Counter as C

class LDA(object):
	def __init__(self,train,test):
		self.train = train
		self.test = test
		self.cls = []
	def extractclass(self):
		"""
		Here we simply count the number of appearances each class has in our training set and return it in an array-like container.
		"""
		x_train = self.train
		cls = C(x[-1] for x in x_train)
		self.cls = cls
	def printclass(self):
		self.extractclass()
		return self.cls



train = [np.array([ 5.4 ,  0.34,  0.  ]), np.array([ 7.6,  0.3,  2. ])]
test = [np.array([ 5.4 ,  0.34,  0.  ]), np.array([ 7.6,  0.3,  2. ])]

LDA = LDA(train,test)
print LDA.printclass()